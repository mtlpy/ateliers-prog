from django.apps import AppConfig


class MonsiteConfig(AppConfig):
    name = 'monsite'
