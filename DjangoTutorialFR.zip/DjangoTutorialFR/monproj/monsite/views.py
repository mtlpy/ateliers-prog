from django.http import HttpResponse

# Create your views here.
