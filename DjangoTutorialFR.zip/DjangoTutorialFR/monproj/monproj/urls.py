"""monproj URL Configuration
The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
"""

from django.urls import path
from django.contrib import admin

urlpatterns = [
    # ajouter les nouveaux paths ici...
    path('admin/', admin.site.urls),
]
